Coupling Step Motor 28BYJ-48 to M4 threaded bar by Rudor on Thingiverse: https://www.thingiverse.com/thing:251910

Summary:
Print with maximum 1 shell. No Support needed.  Thing is printed in 110% of STL for best fit.
